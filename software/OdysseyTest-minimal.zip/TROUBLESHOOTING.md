# Troubleshooting Guide

## Connection Issues: "Socket is not connected"

### What I Just Fixed:

1. **Better error handling** - App now checks connection before sending audio
2. **Auto-stop on failure** - Recording stops automatically if connection fails
3. **Connection delay** - Waits 0.5s for connection before starting to record
4. **Clear error messages** - Shows connection status in the UI

### How to Fix Connection Issues:

#### 1. Check Your iPhone's Internet Connection

**Test your connection:**
- Open Safari on your iPhone
- Visit any website
- Make sure it loads

**WiFi:**
- Go to **Settings → Wi-Fi**
- Make sure you're connected to a network
- Try reconnecting if needed

**Cellular:**
- Go to **Settings → Cellular**
- Make sure Cellular Data is ON
- Check if you have signal

#### 2. Allow Network Access for the App

1. Go to **Settings → OdysseyTest**
2. Look for network/cellular data options
3. Make sure everything is enabled

#### 3. Check Your OpenAI API Key

The error might also be due to authentication issues:

**Verify your API key:**
1. Open `Config.swift` in Xcode
2. Check the API key looks like: `sk-proj-...` (should be long)
3. Go to [https://platform.openai.com/api-keys](https://platform.openai.com/api-keys)
4. Verify your key is active
5. Check you have credits: [https://platform.openai.com/usage](https://platform.openai.com/usage)

#### 4. Test with curl (on your Mac)

Test if your API key works:

```bash
curl -i https://api.openai.com/v1/realtime?model=gpt-4o-realtime-preview-2024-10-01 \
  -H "Authorization: Bearer YOUR_API_KEY_HERE" \
  -H "OpenAI-Beta: realtime=v1"
```

Replace `YOUR_API_KEY_HERE` with your actual key.

**Expected response:**
- Should get `HTTP/1.1 101 Switching Protocols` or similar
- If you get `401 Unauthorized`, your API key is wrong
- If you get connection errors, it's a network issue

#### 5. Firewall/VPN Issues

If you're on a restricted network:
- Disable VPN temporarily
- Try a different WiFi network
- Use cellular data instead

#### 6. Audio Buffer Issue: "0.00ms of audio"

This is a secondary issue caused by the connection failing. Once the connection works, the audio will flow properly.

---

## How to Test Again:

### After Fixing Connection:

1. **Close the app completely** (swipe up to kill it)
2. **Make sure iPhone has internet** (test Safari)
3. **Reopen the app**
4. **Tap the droplet**
5. **Watch for these messages in Xcode console:**
   ```
   Connecting to OpenAI...
   Connected to OpenAI Realtime API
   Conversation started - recording now
   ```

### What You Should See:

✅ Circle turns **green**
✅ Breathing animation starts
✅ **No error messages** in the app
✅ Console shows "Conversation started - recording now"

### If It Still Fails:

Look at the **error message** in the app (red text at bottom). It will tell you:
- "Failed to connect to OpenAI" = Network/internet issue
- "Connection error: [details]" = Specific problem

---

## Quick Debug Checklist:

- [ ] iPhone has internet (test Safari)
- [ ] WiFi or cellular is working
- [ ] API key is correct in `Config.swift`
- [ ] API key is active on OpenAI platform
- [ ] You have credits in your OpenAI account
- [ ] No VPN blocking WebSocket connections
- [ ] App has network permissions

---

## Still Having Issues?

### Check Xcode Console for:

1. **"Connected to OpenAI Realtime API"** - Good, connection worked!
2. **"Connection failed"** - Network or auth issue
3. **"Socket is not connected"** - Network down or blocked
4. **"WebSocket send error"** - Connection dropped mid-stream

### Common Error Solutions:

| Error | Cause | Fix |
|-------|-------|-----|
| "The Internet connection appears to be offline" | No network | Check WiFi/cellular |
| "401 Unauthorized" | Bad API key | Check Config.swift |
| "403 Forbidden" | No credits | Add credits to OpenAI account |
| "Socket is not connected" | Can't reach OpenAI | Check firewall/VPN |
| "0.00ms of audio" | Recording before connection | Wait for green circle |

---

## Testing on Simulator vs Real Device:

**Note:** The simulator might have different network restrictions than your actual iPhone.

- ✅ **Real iPhone**: Best for testing, uses your actual network
- ⚠️ **Simulator**: Uses Mac's network, might have different firewall rules

---

Need more help? Check the console output in Xcode - it shows detailed connection logs!

