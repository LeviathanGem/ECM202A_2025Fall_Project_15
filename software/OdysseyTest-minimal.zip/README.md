# 💧 Odyssey Companion

A calendar-aware hydration JITAI for iOS that blends **BLE activity sensing from Nicla Voice**, **cloud voice via OpenAI Realtime**, and **on-device TinyLlama chat** to deliver hydration nudges at the right moment.

## ✨ Features

### 🎤 Voice Tab (Cloud AI)
- **Real-time voice conversations** with OpenAI's Realtime API
- **Speech-to-speech** interaction with low latency
- **Calendar-aware reasoning** to avoid interrupting meetings
- **Audio level visualization** with breathing animation
- **Live transcription** of your speech and AI responses

### 💬 Chat Tab (Local AI)
- **On-device AI** powered by TinyLlama 1.1B (669MB Q4_K_M quantized)
- **Privacy-first**: All processing happens on your iPhone
- **Apple Speech Recognition** for voice input
- **Conversation history** with chat bubbles
- **BLE-aware context** (keyboard / faucet / background) to infer interruptibility
- **No internet required** after model download

### 📋 Events & Hydration
- **Unified hardware events** from the Nicla Voice sensor
- **Simple hydration logging & goals** via `HydrationStore`
- **Rule-based + LLM prompts** for just-in-time hydration nudges
- **Timestamped logs** with millisecond precision

## 🚀 Getting Started

### Prerequisites

- **Xcode 15.0+**
- **iOS 17.0+** target
- **macOS 14.0+** for development
- **Swift 5.9+**
- **OpenAI API Key** (for Voice tab)
- **~2 GB free space** on iPhone (for local model)

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/OdysseyTest.git
cd OdysseyTest
```

2. **Set up your OpenAI API Key**

   a. Copy the config template:
   ```bash
   cp OdysseyTest/Config.swift.template OdysseyTest/Config.swift
   ```

   b. Edit `OdysseyTest/Config.swift` and add your API key:
   ```swift
   static let apiKey = "sk-proj-your-actual-key-here"
   ```

   c. Get an API key at: https://platform.openai.com/api-keys

3. **Add Privacy Permissions in Xcode**

   a. Open `OdysseyTest.xcodeproj` in Xcode
   
   b. Select the **OdysseyTest** target → **Info** tab
   
   c. Add these keys:
   - `Privacy - Microphone Usage Description`: "We need microphone access for voice interaction with the AI assistant"
   - `Privacy - Speech Recognition Usage Description`: "We use speech recognition to transcribe your hydration-related requests"

4. **Set up Local LLM (Optional - for Chat tab)**

   See [LLAMA_SETUP_INSTRUCTIONS.md](LLAMA_SETUP_INSTRUCTIONS.md) for detailed steps:
   
   - Add `llama.cpp` Swift package
   - Download TinyLlama model (669MB)
   - Configure build settings

5. **Build and Run**
```bash
open OdysseyTest.xcodeproj
# Or use Xcode to build and run (Cmd+R)
```

## 📚 Documentation

- **[SETUP_GUIDE.md](SETUP_GUIDE.md)** - Comprehensive setup instructions
- **[LLAMA_SETUP_INSTRUCTIONS.md](LLAMA_SETUP_INSTRUCTIONS.md)** - Local LLM integration guide
- **[LOCAL_CHAT_GUIDE.md](LOCAL_CHAT_GUIDE.md)** - Chat tab features and usage
- **[TROUBLESHOOTING.md](TROUBLESHOOTING.md)** - Common issues and solutions
- **[TIMESTAMP_SYSTEM.md](TIMESTAMP_SYSTEM.md)** - Performance monitoring documentation
- **[LLM_INTEGRATION_COMPLETE.md](LLM_INTEGRATION_COMPLETE.md)** - Technical deep-dive

## 🏗️ Architecture

### Tech Stack
- **SwiftUI** - Modern declarative UI framework
- **AVFoundation** - Audio recording and processing
- **Speech Framework** - On-device speech recognition
- **URLSession WebSocket** - Real-time OpenAI connection
- **llama.cpp** - Local LLM inference engine

### Project Structure
```
OdysseyTest/
├── OdysseyTest/
│   ├── OdysseyTestApp.swift          # App entry + TabView
│   ├── ContentView.swift             # Voice tab UI
│   ├── ChatView.swift                # Chat tab UI
│   ├── AudioRecorder.swift           # Microphone handling
│   ├── OpenAIRealtimeService.swift   # OpenAI WebSocket client
│   ├── ConversationManager.swift     # Shared state management
│   ├── LocalSpeechRecognizer.swift   # Apple Speech Recognition
│   ├── LLMManager.swift              # Local model inference
│   ├── LLMConfig.swift               # Model configuration
│   ├── ModelDownloader.swift         # Model download handler
│   ├── Message.swift                 # Chat message model
│   ├── HydrationStore.swift          # Hydration state + persistence
│   ├── JITAIReasoner.swift           # Rule-based hydration prompts
│   ├── TimestampUtility.swift        # Performance logging
│   └── Config.swift                  # API keys (gitignored)
├── README.md                         # This file
├── .gitignore                        # Git ignore rules
└── [Documentation files...]
```

## 🔐 Security Notes

- **API Keys**: `Config.swift` is gitignored - never commit your API key!
- **Local Processing**: Chat tab runs entirely on-device (private)
- **Network**: Only Voice tab requires internet connection
- **Permissions**: Microphone and speech recognition are request-based

## 📱 Performance

### Voice Tab (Cloud AI)
- **Latency**: ~500-1000ms for speech-to-response
- **Network**: Requires stable internet (WebSocket)
- **Battery**: ~5-7% per 10 minutes of active use

### Chat Tab (Local AI)
- **Load Time**: 2-3 seconds (first launch)
- **Generation**: 15-20 tokens/second on iPhone 15 Pro
- **RAM Usage**: ~920 MB during inference
- **Battery**: ~5% per 10 minutes of active use

## 🧪 Testing

Run tests in Xcode:
```bash
# Unit tests
xcodebuild test -project OdysseyTest.xcodeproj -scheme OdysseyTest -sdk iphonesimulator

# Or use Xcode: Cmd+U
```

## 🐛 Troubleshooting

### "API Key Required" Alert
- Make sure you've created `Config.swift` from the template
- Verify your API key is valid and starts with `sk-proj-`

### "Microphone Permission Required"
- Go to Settings → Privacy & Security → Microphone → Enable for OdysseyTest

### Voice tab not working
- Check internet connection
- Verify OpenAI API key has Realtime API access
- Check [TROUBLESHOOTING.md](TROUBLESHOOTING.md)

### Chat tab shows "Tap to download model"
- Follow [LLAMA_SETUP_INSTRUCTIONS.md](LLAMA_SETUP_INSTRUCTIONS.md)
- Model download is 669MB - ensure WiFi and storage space

## 📄 License

[Add your license here - e.g., MIT, Apache 2.0, etc.]

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📧 Contact

[Your Name] - [Your Email]

Project Link: [https://github.com/yourusername/OdysseyTest](https://github.com/yourusername/OdysseyTest)
