# BLE + LLM Integration - Testing Guide 🧪

## Quick Test Sequence

### Test 1: Basic BLE → LLM Flow

**1. Start Arduino**
```
Arduino Serial Monitor should show:
✅ Ready! Say 'Alexa' to test.
🔵 BLE device active, waiting for connections...
```

**2. Connect iPhone**
```
iOS App → BLE Setup → Scan → Tap "Alexa Nicla"
Arduino shows: ✅ Connected to central: ...
```

**3. Trigger Alexa Detection**
```
Say "Alexa" near Arduino
Arduino shows: 
  - Blue LED blinks
  - 📤 Sent BLE: MATCH: Alexa
  
iPhone shows:
  - Tap "Detected Events (1)"
  - See: 🎤 Alexa: Alexa
```

**4. Test Local LLM**
```
iOS App → (open local chat if available)
Type: "What hardware events happened recently?"

LLM Should Respond:
  "I detected an Alexa wake word event ... seconds ago..."
```

**5. Test Cloud LLM**
```
iOS App → Tap droplet (OpenAI)
Say: "What just happened?"

OpenAI Should Respond:
  "I noticed your Alexa device was triggered..."
```

---

### Test 2: Arduino Test Command

**1. Connect Everything**
- Arduino connected via USB + Serial Monitor open
- iPhone connected via BLE
- iOS app running

**2. Send Test Message**
```
Arduino Serial Monitor → Type: t (lowercase)
Press Enter

Arduino shows:
  📤 Sending test message...
  ✅ Test message sent

iPhone shows:
  Tap "Detected Events"
  See: 🧪 Test: Hello from Nicla!
```

**3. Ask LLM About It**
```
Local Chat → Type: "Did you receive anything from the hardware?"

Expected:
  "Yes! I received a test message..."
```

---

### Test 3: Multiple Events

**1. Generate Several Events**
```
1. Say "Alexa" near Arduino
2. Wait 5 seconds
3. Arduino Serial → Type: t
4. Wait 5 seconds
5. Say "Alexa" again
```

**2. Check Events List**
```
iPhone → Tap "Detected Events (3)"
Should see:
  🎤 Alexa: Alexa (2s ago)
  🧪 Test: Hello from Nicla! (7s ago)
  🎤 Alexa: Alexa (12s ago)
```

**3. Ask LLM for Summary**
```
Local Chat → Type: "What hardware events have you seen?"

Expected:
  "I've detected several hardware events:
   - Alexa wake word (most recent)
   - A test message from Nicla
   - An earlier Alexa detection
   ..."
```

---

### Test 4: Context Freshness

**1. Old Event**
```
- Say "Alexa"
- Wait 60 seconds
```

**2. Ask LLM**
```
Type: "What happened recently?"

Expected:
  Mentions Alexa event with "1m ago" or similar
```

**3. New Event**
```
- Arduino Serial → Type: t
- Immediately ask: "What just happened?"

Expected:
  Focuses on the test message (more recent)
  May still mention Alexa as older context
```

---

## Expected Behaviors

### Local LLM Context

**Prompt Structure:**
```
System: You are a hydration JITAI assistant...

=== Recent Hardware Events ===
• 🎤 Alexa: Alexa (5s ago)
• 🧪 Test: Hello from Nicla! (30s ago)

User: [your question]
Assistant:
```

### Cloud OpenAI Context

**Session Instructions Include:**
```
You are a hydration JITAI assistant...
Be aware of hardware events...

=== Recent Hardware Events ===
• 🎤 Alexa: Alexa (5s ago)
• 🧪 Test: Hello from Nicla! (30s ago)
```

---

## Verification Points

### ✅ BLE → Events
- [ ] Arduino detection → iPhone event appears
- [ ] Correct icon (🎤 for Alexa, 🧪 for test)
- [ ] Timestamp accurate
- [ ] Multiple events accumulate

### ✅ Events → Local LLM
- [ ] LLM mentions BLE events when asked
- [ ] Time references accurate ("5s ago")
- [ ] Multiple events described correctly
- [ ] Old events eventually forgotten (keeps last 10)

### ✅ Events → Cloud LLM
- [ ] OpenAI aware of BLE events
- [ ] Mentions hardware context naturally
- [ ] Updates when new events arrive
- [ ] Works during active conversation

### ✅ End-to-End
- [ ] Arduino → BLE → Event → LLM → Response (complete flow)
- [ ] No crashes or errors
- [ ] Console shows expected logs
- [ ] Performance feels instant

---

## Debugging Tips

### No Events Appearing?

**Check Arduino:**
```
- LED should blink when "Alexa" detected
- Serial should show: 📤 Sent BLE: ...
- Should show: ✅ Connected to central: ...
```

**Check iPhone:**
```
- "BLE Connected" indicator green?
- Xcode console shows: 📡 BLE event sent to LLM systems
- Events tab has count > 0?
```

### LLM Not Mentioning Events?

**Check Context:**
```swift
// Add to ChatView.syncBLEEventsToLLM()
print("Syncing \(bleEvents.count) BLE events to LLM")
print(llmManager.getBLEContext())

// Should print:
Syncing 2 BLE events to LLM
Recent hardware events:
• 🎤 Alexa: Alexa (5s ago)
• 🧪 Test: Hello from Nicla! (30s ago)
```

**Check OpenAI:**
```swift
// Add to OpenAIRealtimeService.updateBLEContext()
print("OpenAI context:\n\(bleEventsContext)")

// Should print formatted events
```

### Events Showing But Wrong Time?

**Check Timestamps:**
```swift
// In DetectedEvent
print("Event created at: \(timestamp)")
print("Current time: \(Date())")
print("Diff: \(Date().timeIntervalSince(timestamp))s")
```

---

## Sample Conversations

### Conversation 1: Discovery

**User:** "Hi"  
**LLM:** "Hello! How can I help you today?"

**User:** "What can you see?"  
**LLM:** "I can see your conversation history and any hardware events from your connected devices. Right now, everything looks quiet. Is there something specific you'd like to know about?"

**[User says "Alexa" near Arduino]**

**User:** "Did you notice that?"  
**LLM:** "Yes! I just detected an Alexa wake word from your hardware device a moment ago. Someone said 'Alexa' near your Arduino sensor. Would you like to do something with that information?"

### Conversation 2: Context Awareness

**[User triggers multiple events]**
- Alexa detection
- Test message  
- Another Alexa

**User:** "What's been happening?"  
**LLM:** "I've noticed quite a bit of activity from your hardware! In the last minute:
- Two Alexa wake word detections (the most recent was just 5 seconds ago)
- A test message from your Nicla device

It looks like you're actively testing the system. Everything seems to be working well!"

### Conversation 3: Helpful Assistant

**[Alexa detected]**

**User:** "I want a hydration check"  
**LLM:** "I see you just triggered your sensor and want a hydration check. Here's a quick nudge: take ~200 ml now. [FUNCTION:hydration_prompt] Want me to log it?"

---

## Advanced Testing

### Stress Test: Many Events

```
1. Generate 20+ events rapidly
2. Check: Only last 10 stored (local LLM)
3. Check: Only last 5 in prompt context
4. Ask LLM: Should only mention recent ones
```

### Latency Test

```
1. Say "Alexa"
2. Time from LED blink to asking LLM
3. Should feel instant (<1s total):
   - BLE: <10ms
   - Event creation: <1ms
   - Context update: <1ms
   - LLM sees it: immediately
```

### Persistence Test

```
1. Generate event
2. Close app
3. Reopen app
4. Check: Events still there (they should be)
5. Ask LLM: Should still know about them
```

---

## Success Criteria

✅ **All tests pass without errors**  
✅ **Events appear within 1 second of Arduino trigger**  
✅ **LLMs mention events when relevant**  
✅ **No memory leaks or performance issues**  
✅ **Context stays up-to-date automatically**  
✅ **Old events don't clutter responses**  

When all these work, your BLE + LLM integration is **production-ready**! 🎉

---

## Quick Reference

| Arduino Command | What It Does | iPhone Shows |
|----------------|--------------|--------------|
| Say "Alexa" | Triggers wake word | 🎤 Alexa: Alexa |
| Type `t` | Sends test message | 🧪 Test: Hello from Nicla! |
| Type `f` | Disable interrupts | ⚙️ Interrupts disabled |
| Type `o` | Enable interrupts | ⚙️ Interrupts enabled |

| LLM Question | Expected Response Type |
|--------------|----------------------|
| "What happened?" | Mentions recent BLE events |
| "Any hardware events?" | Lists recent detections |
| "Did you see that?" | References specific event |
| "What's going on?" | General status + BLE context |

---

**Happy Testing!** 🧪🤖📡

