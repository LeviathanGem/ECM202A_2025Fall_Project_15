# Timestamp System - Performance Testing & Debugging

## Overview

All major operations in the OdysseyTest app are now instrumented with **millisecond-precision timestamps** for performance testing, debugging, and optimization.

---

## Timestamp Utility

### Core Functions

```swift
// Current timestamp with milliseconds
TimestampUtility.now                    // "2025-10-26 23:45:12.345"
TimestampUtility.nowISO                 // "2025-10-26T23:45:12.345Z"
TimestampUtility.nowUnix                // 1729987512345

// Elapsed time calculation
let startTime = Date()
// ... do work ...
let elapsed = TimestampUtility.elapsed(since: startTime)  // in milliseconds

// Formatted logging
TimestampUtility.log("Message", category: "CategoryName")
TimestampUtility.logPerformance("Operation", duration: milliseconds)
```

### Date Extensions

```swift
let timestamp = Date().timestamp        // "2025-10-26 23:45:12.345"
let timeOnly = Date().timestampTime     // "23:45:12.345"
let unixMs = Date().unixMs              // 1729987512345
```

---

## Instrumented Components

### 1. **AudioRecorder.swift**
Tracks audio recording operations:

```
[2025-10-26 23:45:12.345] [AudioRecorder] Starting audio recording...
[2025-10-26 23:45:12.398] [PERFORMANCE] Audio recording start: 53ms
[2025-10-26 23:45:30.125] [AudioRecorder] Stopping audio recording
[2025-10-26 23:45:30.127] [AudioRecorder] Audio recording stopped
```

**Measured Operations:**
- `startRecording()` - Time to initialize audio engine
- `stopRecording()` - Cleanup time

---

### 2. **LocalSpeechRecognizer.swift**
Tracks on-device speech recognition:

```
[2025-10-26 23:45:12.500] [SpeechRecognizer] Starting speech recognition...
[2025-10-26 23:45:12.545] [PERFORMANCE] Speech recognition setup: 45ms
[2025-10-26 23:45:13.200] [SpeechRecognizer] Transcription update: Hello there
[2025-10-26 23:45:15.800] [PERFORMANCE] Speech recognition completed: 3300ms
[2025-10-26 23:45:15.801] [SpeechRecognizer] Final transcription: Hello there
```

**Measured Operations:**
- `startRecording()` - Setup time
- Real-time transcription updates
- Total recognition time (start to final transcription)
- `stopRecording()` - Cleanup

---

### 3. **OpenAIRealtimeService.swift**
Tracks WebSocket connection and API responses:

```
[2025-10-26 23:45:12.000] [OpenAI] Connecting to OpenAI Realtime API...
[2025-10-26 23:45:12.234] [PERFORMANCE] OpenAI WebSocket connection: 234ms
[2025-10-26 23:45:15.100] [OpenAI] Received: conversation.item.input_audio_transcription.completed
[2025-10-26 23:45:15.101] [OpenAI] Transcription completed (1ms): hydration prompt
[2025-10-26 23:45:16.500] [OpenAI] Function call detected: hydration_prompt
[2025-10-26 23:45:17.200] [PERFORMANCE] OpenAI response completed: 2100ms
[2025-10-26 23:45:30.000] [OpenAI] Disconnecting from OpenAI Realtime API
[2025-10-26 23:45:30.050] [OpenAI] Disconnected from OpenAI Realtime API
```

**Measured Operations:**
- `connect()` - WebSocket connection time
- Message processing per message type
- Response completion time (speech → response)
- `disconnect()` - Disconnection time
- Error logging with timestamps

---

### 4. **LLMManager.swift**
Tracks local LLM model operations:

```
[2025-10-26 23:45:00.000] [LLMManager] Loading LLM model...
[2025-10-26 23:45:02.123] [PERFORMANCE] LLM model loading: 2123ms
[2025-10-26 23:45:02.124] [LLMManager] LLM loaded successfully (mock)

[2025-10-26 23:45:10.000] [LLMManager] Generating response for: hydration prompt...
[2025-10-26 23:45:11.545] [PERFORMANCE] LLM generation: 1545ms
[2025-10-26 23:45:11.546] [LLMManager] Response: Nudging a sip now... | Event: hydration_prompt
```

**Measured Operations:**
- `loadModel()` - Model initialization time
- `generate()` - Inference time per prompt
- Event extraction

---

### 5. **ConversationManager.swift**
Tracks end-to-end conversation flow:

```
[2025-10-26 23:45:12.000] [ConversationManager] Starting conversation...
[2025-10-26 23:45:12.789] [PERFORMANCE] Conversation started (connection + setup): 789ms
[2025-10-26 23:45:30.000] [ConversationManager] Stopping conversation
[2025-10-26 23:45:30.002] [ConversationManager] Conversation stopped
```

**Measured Operations:**
- `startConversation()` - Full initialization (permissions + OpenAI connection + audio setup)
- Rate limiting checks
- `stopConversation()` - Cleanup time
- Permission checks

---

### 6. **Message.swift & DetectedEvent**
Tracks message and event creation:

```
[2025-10-26 23:45:15.000] [Message] Message created: user - hydration prompt...
[2025-10-26 23:45:16.500] [Event] Event detected: hydration_prompt
```

**Properties:**
- `message.timestampMs` - Formatted timestamp
- `message.timestampUnix` - Unix timestamp in milliseconds
- `event.timestampMs` - Formatted timestamp
- `event.timestampUnix` - Unix timestamp in milliseconds

---

## Log Format

### Standard Log Entry
```
[YYYY-MM-DD HH:MM:SS.mmm] [Category] Message
```

### Performance Log Entry
```
[YYYY-MM-DD HH:MM:SS.mmm] [PERFORMANCE] Operation: XXXms (or X.XXs)
```

### Error Log Entry
```
[YYYY-MM-DD HH:MM:SS.mmm] [Category] ERROR: Error message
```

---

## Categories Used

| Category | Component | Purpose |
|----------|-----------|---------|
| `AudioRecorder` | AudioRecorder.swift | Audio capture events |
| `SpeechRecognizer` | LocalSpeechRecognizer.swift | Speech-to-text operations |
| `OpenAI` | OpenAIRealtimeService.swift | Cloud API interactions |
| `LLMManager` | LLMManager.swift | Local LLM operations |
| `ConversationManager` | ConversationManager.swift | High-level conversation flow |
| `Message` | Message.swift | Chat message creation |
| `Event` | ConversationManager.swift | Event detection |
| `PERFORMANCE` | All | Performance measurements |

---

## Usage Examples

### Example 1: Measuring Custom Operations

```swift
let startTime = Date()

// Your operation here
performExpensiveOperation()

let elapsed = TimestampUtility.elapsed(since: startTime)
TimestampUtility.logPerformance("Custom operation", duration: elapsed)
```

### Example 2: Adding Timestamps to New Features

```swift
func myNewFeature() {
    TimestampUtility.log("Starting new feature", category: "MyFeature")
    
    // Do work
    
    TimestampUtility.log("New feature completed", category: "MyFeature")
}
```

### Example 3: Accessing Message Timestamps

```swift
let message = Message(text: "Hello", sender: .user)
print(message.timestampMs)      // "2025-10-26 23:45:12.345"
print(message.timestampUnix)    // 1729987512345
```

---

## Performance Benchmarks

Based on current implementation (mock mode for LLM):

| Operation | Typical Duration | Notes |
|-----------|------------------|-------|
| Audio Recording Start | 30-100ms | Depends on device |
| OpenAI Connection | 200-500ms | Network dependent |
| Speech Recognition Setup | 30-70ms | On-device |
| OpenAI Transcription | 1-3s | Speech → text |
| OpenAI Response | 2-5s | Full round trip |
| Local LLM Loading | 2-10s | Model size dependent |
| Local LLM Generation | 0.5-3s | Prompt length dependent |
| Conversation Start | 700-1200ms | End-to-end setup |

---

## Testing & Debugging Tips

### 1. **Filter Logs by Category**
```bash
# In Xcode console
grep "\[OpenAI\]" 
grep "\[PERFORMANCE\]"
grep "ERROR"
```

### 2. **Track End-to-End Latency**
Look for pairs of logs:
- `[ConversationManager] Starting conversation...`
- `[PERFORMANCE] Conversation started...`

### 3. **Identify Bottlenecks**
Compare `[PERFORMANCE]` logs to find slowest operations.

### 4. **Monitor API Performance**
Track time between:
- `[OpenAI] Transcription completed`
- `[OpenAI] Function call detected`

### 5. **Check for Errors**
All errors are logged with `ERROR:` prefix and timestamps.

---

## Future Enhancements

1. **Log Export**: Add ability to export timestamped logs to file
2. **Analytics Dashboard**: Visualize performance metrics over time
3. **Alerting**: Warn if operations exceed expected duration
4. **Network Timing**: Add detailed network request/response timing
5. **Memory Tracking**: Correlate timestamps with memory usage

---

## Implementation Files

- **TimestampUtility.swift** - Core utility functions
- **AudioRecorder.swift** - Audio recording timestamps
- **LocalSpeechRecognizer.swift** - Speech recognition timestamps
- **OpenAIRealtimeService.swift** - API call timestamps
- **LLMManager.swift** - LLM operation timestamps
- **ConversationManager.swift** - Conversation flow timestamps
- **Message.swift** - Message/event creation timestamps

---

## Notes

- All timestamps are in **local time zone** unless using ISO format
- Millisecond precision is maintained throughout
- Performance logs automatically format duration (ms for < 1s, seconds otherwise)
- Unix timestamps are useful for precise time calculations and database storage
- Categories help filter and organize logs during debugging

---

Last Updated: November 3, 2025

