//
//  OdysseyTestApp.swift
//  OdysseyTest
//
//  Created by Assia LI on 2025/10/24.
//

import SwiftUI

@main
struct OdysseyTestApp: App {
    @StateObject private var sharedConversationManager = ConversationManager(apiKey: Config.apiKey)
    
    var body: some Scene {
        WindowGroup {
            TabView {
                // AI Chat Tab - Unified Cloud/Local/Hybrid with BLE
                NavigationView {
                    UnifiedChatView(conversationManager: sharedConversationManager)
                }
                .tabItem {
                    Label("AI Chat", systemImage: "message.fill")
                }
                
                // Events Tab - Unified event history
                NavigationView {
                    EventsHistoryView(conversationManager: sharedConversationManager)
                }
                .tabItem {
                    Label("Events", systemImage: "list.bullet")
                }
                
                // Calendar Tab - Agenda management
                NavigationView {
                    CalendarView()
                }
                .tabItem {
                    Label("Calendar", systemImage: "calendar")
                }
                
                // Hydration Tab - Daily water intake tracker
                NavigationView {
                    HydrationView()
                }
                .tabItem {
                    Label("Hydration", systemImage: "drop.fill")
                }
            }
        }
    }
}

// MARK: - Events History View

struct EventsHistoryView: View {
    @ObservedObject var conversationManager: ConversationManager
    
    var body: some View {
        List {
            if conversationManager.detectedEvents.isEmpty {
                VStack(spacing: 16) {
                    Image(systemName: "tray")
                        .font(.system(size: 60))
                        .foregroundColor(.gray.opacity(0.5))
                    
                    Text("No Events Yet")
                        .font(.title3)
                        .foregroundColor(.gray)
                    
                    Text("Events from both Voice and Chat will appear here")
                        .font(.caption)
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding(.top, 100)
            } else {
                ForEach(conversationManager.detectedEvents) { event in
                    VStack(alignment: .leading, spacing: 5) {
                        Text(event.displayName)
                            .font(.headline)
                        Text(event.timestamp.formatted(date: .abbreviated, time: .standard))
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    .padding(.vertical, 5)
                }
            }
        }
        .navigationTitle("Event History")
        .toolbar {
            if !conversationManager.detectedEvents.isEmpty {
                Button("Clear") {
                    conversationManager.clearEvents()
                }
            }
        }
    }
}
