//
//  Config.swift
//  OdysseyTest
//
//  Configuration and API key management
//

import Foundation

struct Config {
    // IMPORTANT: Never commit your actual API key to version control!
    // Best practice: Use environment variables or Keychain
    
    // For development, you can temporarily put your key here:
    static let openAIAPIKey = "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"
    
    // Alternative: Load from environment variable
    static var openAIAPIKeyFromEnv: String {
        ProcessInfo.processInfo.environment["OPENAI_API_KEY"] ?? openAIAPIKey
    }
    
    // Use this in your app
    static var apiKey: String {
        openAIAPIKeyFromEnv
    }
    
    // Validate API key
    static var isAPIKeyConfigured: Bool {
        !apiKey.isEmpty && apiKey != "YOUR_API_KEY_HERE"
    }
}

