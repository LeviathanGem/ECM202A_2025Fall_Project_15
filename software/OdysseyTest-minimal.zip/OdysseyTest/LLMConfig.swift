//
//  LLMConfig.swift
//  OdysseyTest
//
//  Configuration for local LLM
//

import Foundation

struct LLMConfig {
    // Model configuration
    static let modelName = "tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf"
    static let modelURL = "https://huggingface.co/TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF/resolve/main/tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf"
    static let modelSize: Int64 = 669_000_000 // ~669 MB
    
    // Model path in documents directory
    static var modelPath: URL {
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return documentsPath.appendingPathComponent(modelName)
    }
    
    // Check if model exists
    static var isModelDownloaded: Bool {
        FileManager.default.fileExists(atPath: modelPath.path)
    }
    
    // Generation parameters
    static let maxTokens = 150
    static let temperature: Float = 0.7
    static let topP: Float = 0.9
    static let repeatPenalty: Float = 1.1
    
    // System prompt for hydration JITAI assistant
    static let systemPrompt = """
    You are a just-in-time hydration coach. Blend sensor activity, recent hydration, and calendar context to decide whether to nudge the user to drink water.
    Keep responses brief, actionable, and encouraging. Avoid questions unless clarifying a goal.
    
    Available functions:
    - log_water_intake: When the user reports drinking a specific amount
    - hydration_status: When the user asks about progress toward their daily goal
    - set_hydration_goal: When the user wants to change their daily target
    - hydration_prompt: When you proactively suggest taking a sip
    
    When you detect these intents, include [FUNCTION:function_name] in your response.
    Emphasize timing (breaks vs meetings), respect do-not-disturb contexts, and use ml amounts when suggesting intake.
    """
}

