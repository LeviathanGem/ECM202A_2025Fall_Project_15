//
//  LLMManager.swift
//  OdysseyTest
//
//  Manages local LLM inference
//
//  TODO: After adding llama.cpp dependency:
//  1. Uncomment the import statement below
//  2. Uncomment the llama.cpp integration code
//  3. Remove the mock implementation
//

import Foundation
#if canImport(llama)
import llama
#endif

class LLMManager: ObservableObject {
    @Published var isLoaded = false
    @Published var isGenerating = false
    @Published var loadError: String?
    
    private var conversationHistory: [Message] = []
    private var bleEvents: [DetectedEvent] = []  // Track BLE events for context
    
    #if canImport(llama)
    private var context: LlamaContext?
    private var model: LlamaModel?
    #endif
    
    // MARK: - Model Loading
    
    func loadModel() {
        let startTime = Date()
        guard !isLoaded else { return }
        guard LLMConfig.isModelDownloaded else {
            loadError = "Model not downloaded"
            TimestampUtility.log("ERROR: Model not downloaded", category: "LLMManager")
            return
        }
        
        TimestampUtility.log("Loading LLM model...", category: "LLMManager")
        
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            
            #if canImport(llama)
            do {
                let modelPath = LLMConfig.modelPath.path
                self.model = try LlamaModel(path: modelPath)
                self.context = try LlamaContext(model: self.model!)
                
                let elapsed = TimestampUtility.elapsed(since: startTime)
                DispatchQueue.main.async {
                    self.isLoaded = true
                    TimestampUtility.logPerformance("LLM model loading", duration: elapsed)
                    TimestampUtility.log("LLM loaded successfully (llama.cpp)", category: "LLMManager")
                    DebugLogger.shared.log(.info, category: "LLM", message: "Local model loaded")
                }
            } catch {
                DispatchQueue.main.async {
                    self.loadError = "Failed to load model: \(error.localizedDescription)"
                    TimestampUtility.log("ERROR: Failed to load model: \(error.localizedDescription)", category: "LLMManager")
                    DebugLogger.shared.log(.error, category: "LLM", message: "Load failed: \(error.localizedDescription)")
                }
            }
            #else
            // Fallback mock when llama package is not available
            Thread.sleep(forTimeInterval: 2.0)
            let elapsed = TimestampUtility.elapsed(since: startTime)
            DispatchQueue.main.async {
                self.isLoaded = true
                TimestampUtility.logPerformance("LLM model loading", duration: elapsed)
                TimestampUtility.log("LLM loaded successfully (mock)", category: "LLMManager")
                DebugLogger.shared.log(.warn, category: "LLM", message: "Running in mock mode; add SwiftLlama to use real model.")
            }
            #endif
        }
    }
    
    func unloadModel() {
        #if canImport(llama)
        context = nil
        model = nil
        #endif
        
        isLoaded = false
        conversationHistory.removeAll()
        print("LLM unloaded")
    }
    
    // MARK: - Text Generation
    
    func generate(prompt: String, completion: @escaping (String, String?) -> Void) {
        let startTime = Date()
        
        guard isLoaded else {
            TimestampUtility.log("ERROR: Attempted generation with unloaded model", category: "LLMManager")
            completion("", "Model not loaded")
            return
        }
        
        TimestampUtility.log("Generating response for: \(prompt.prefix(100))...", category: "LLMManager")
        
        isGenerating = true
        
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            
            // Build full prompt with system message and conversation history
            let fullPrompt = self.buildPrompt(userMessage: prompt)
            
            #if canImport(llama)
            do {
                let output = try self.context?.generate(
                    prompt: fullPrompt,
                    maxTokens: LLMConfig.maxTokens,
                    temperature: LLMConfig.temperature,
                    topP: LLMConfig.topP,
                    repeatPenalty: LLMConfig.repeatPenalty
                )
                
                let response = output ?? ""
                let event = self.extractEvent(from: response)
                
                let elapsed = TimestampUtility.elapsed(since: startTime)
                TimestampUtility.logPerformance("LLM generation", duration: elapsed)
                DebugLogger.shared.log(.debug, category: "LLM", message: "Generated response (\(elapsed)ms)")
                
                DispatchQueue.main.async {
                    self.isGenerating = false
                    completion(response, event)
                }
            } catch {
                let message = "Generation failed: \(error.localizedDescription)"
                TimestampUtility.log("ERROR: \(message)", category: "LLMManager")
                DebugLogger.shared.log(.error, category: "LLM", message: message)
                DispatchQueue.main.async {
                    self.isGenerating = false
                    completion("", message)
                }
            }
            #else
            // Mock implementation when llama is unavailable
            Thread.sleep(forTimeInterval: 1.5)
            let mockResponse = self.generateMockResponse(for: prompt)
            let event = self.extractEvent(from: mockResponse)
            
            let elapsed = TimestampUtility.elapsed(since: startTime)
            TimestampUtility.logPerformance("LLM generation", duration: elapsed)
            TimestampUtility.log("Response: \(mockResponse.prefix(100))... | Event: \(event ?? "none")", category: "LLMManager")
            
            DispatchQueue.main.async {
                self.isGenerating = false
                completion(mockResponse, event)
            }
            #endif
        }
    }
    
    // MARK: - Prompt Building
    
    private func buildPrompt(userMessage: String) -> String {
        var prompt = LLMConfig.systemPrompt + "\n\n"
        
        // Add BLE context if there are recent events
        if !bleEvents.isEmpty {
            prompt += "=== Recent Hardware Events ===\n"
            for event in bleEvents.suffix(5) { // Last 5 BLE events
                let timeAgo = formatTimeAgo(event.timestamp)
                prompt += "• \(event.displayName) (\(timeAgo))\n"
            }
            prompt += "\n"
        }
        
        // Add conversation history
        for message in conversationHistory.suffix(6) { // Keep last 6 messages for context
            let role = message.sender == .user ? "User" : "Assistant"
            prompt += "\(role): \(message.text)\n"
        }
        
        // Add current user message
        prompt += "User: \(userMessage)\nAssistant:"
        
        return prompt
    }
    
    private func formatTimeAgo(_ date: Date) -> String {
        let seconds = Int(Date().timeIntervalSince(date))
        if seconds < 60 {
            return "\(seconds)s ago"
        } else if seconds < 3600 {
            return "\(seconds / 60)m ago"
        } else {
            return "\(seconds / 3600)h ago"
        }
    }
    
    // MARK: - Event Extraction
    
    private func extractEvent(from response: String) -> String? {
        // Look for [FUNCTION:function_name] in response
        if let range = response.range(of: #"\[FUNCTION:(\w+)\]"#, options: .regularExpression) {
            let functionTag = String(response[range])
            if let functionName = functionTag.split(separator: ":").last?.dropLast() {
                return String(functionName)
            }
        }
        
        // Fallback: Simple keyword detection
        let lowercased = response.lowercased()
        if lowercased.contains("log") && (lowercased.contains("water") || lowercased.contains("drink")) {
            return "log_water_intake"
        } else if lowercased.contains("goal") {
            return "set_hydration_goal"
        } else if lowercased.contains("status") || lowercased.contains("progress") {
            return "hydration_status"
        } else if lowercased.contains("remind") || lowercased.contains("reminder") || lowercased.contains("hydrate") {
            return "hydration_prompt"
        }
        
        return nil
    }
    
    // MARK: - Conversation Management
    
    func addToHistory(_ message: Message) {
        conversationHistory.append(message)
        
        // Keep history manageable
        if conversationHistory.count > 20 {
            conversationHistory.removeFirst(conversationHistory.count - 20)
        }
    }
    
    func clearHistory() {
        conversationHistory.removeAll()
    }
    
    // MARK: - BLE Event Management
    
    func addBLEEvent(_ event: DetectedEvent) {
        bleEvents.append(event)
        
        // Keep BLE events manageable (last 10)
        if bleEvents.count > 10 {
            bleEvents.removeFirst(bleEvents.count - 10)
        }
        
        TimestampUtility.log("LLM context updated with BLE event: \(event.name)", category: "LLMManager")
    }
    
    func clearBLEEvents() {
        bleEvents.removeAll()
    }
    
    func getBLEContext() -> String {
        guard !bleEvents.isEmpty else {
            return "No recent hardware events."
        }
        
        var context = "Recent hardware events:\n"
        for event in bleEvents.suffix(5) {
            let timeAgo = formatTimeAgo(event.timestamp)
            context += "• \(event.displayName) (\(timeAgo))\n"
        }
        return context
    }
    
    // MARK: - Mock Implementation (used only when llama is unavailable)
    
    private func generateMockResponse(for prompt: String) -> String {
        let lowercased = prompt.lowercased()
        
        if lowercased.contains("hello") || lowercased.contains("hi") {
            return "Hello! I'm your local hydration coach running entirely on your iPhone. How can I help you today?"
        } else if lowercased.contains("log") && (lowercased.contains("water") || lowercased.contains("drink")) {
            return "Got it. I'll log that intake now. [FUNCTION:log_water_intake] Keep the sips coming!"
        } else if lowercased.contains("goal") {
            return "Sure, let's adjust your daily target. [FUNCTION:set_hydration_goal] What goal should I set in ml?"
        } else if lowercased.contains("status") || lowercased.contains("progress") || lowercased.contains("how am i doing") {
            return "You're asking about today's hydration. [FUNCTION:hydration_status] I'll summarize your intake and what's left."
        } else if lowercased.contains("remind") || lowercased.contains("hydrate") || lowercased.contains("thirst") {
            return "Here's a gentle nudge: take ~200–250 ml now if you can. [FUNCTION:hydration_prompt]"
        } else if lowercased.contains("help") {
            return "I can help you with:\n• Logging water you just drank\n• Checking your progress vs today’s goal\n• Setting a new hydration goal\n• Offering timely nudges when you're behind\n\nJust speak naturally and I'll keep it short."
        } else {
            return "I understand you said: '\(prompt)'. As your local hydration coach, I can log water, update your goal, summarize your status, or give you a quick nudge to sip."
        }
    }
}

