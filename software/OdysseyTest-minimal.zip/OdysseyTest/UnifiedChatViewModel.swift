//
//  UnifiedChatViewModel.swift
//  OdysseyTest
//
//  View model managing Cloud, Local, and Hybrid chat modes
//

import Foundation
import Combine

class UnifiedChatViewModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var selectedMode: ChatMode = .cloud
    @Published var isProcessing = false
    @Published var isLocalModelLoaded = false
    
    private let conversationManager: ConversationManager
    private let llmManager = LLMManager()
    private let chatService = OpenAIChatService(apiKey: Config.apiKey)
    private let speechRecognizer = LocalSpeechRecognizer()
    private let nudgeHistoryStore = NudgeHistoryStore.shared
    private let calendarManager = CalendarManager()
    private var nudgeTimer: Timer?
    private let nudgeQueue = DispatchQueue(label: "odyssey.nudge.queue", qos: .utility)
    
    // Activity streak tracking to stabilize noisy ACT streams
    private var activityStreakLabel: ActivityLabel = .unknown
    private var activityStreakCount: Int = 0
    private var lastStableActivity: ActivityLabel = .unknown
    private var lastStableActivityAt: Date = .distantPast
    
    init(conversationManager: ConversationManager) {
        self.conversationManager = conversationManager
        setupCallbacks()
        startNudgeLoop()
    }
    
    deinit {
        nudgeTimer?.invalidate()
    }
    
    // MARK: - Setup
    
    private func setupCallbacks() {
        // Monitor local model status
        llmManager.$isLoaded
            .assign(to: &$isLocalModelLoaded)
    }
    
    // MARK: - Message Sending
    
    func sendMessage(_ text: String) {
        // Add user message
        let userMessage = ChatMessage(text: text, isUser: true, source: .user)
        messages.append(userMessage)
        
        // Process based on mode
        switch selectedMode {
        case .cloud:
            sendToCloud(text)
        case .local:
            sendToLocal(text)
        case .hybrid:
            sendToHybrid(text)
        }
    }
    
    // MARK: - Cloud Mode
    
    private func sendToCloud(_ text: String) {
        isProcessing = true
        
        let systemPrompt = """
        You are a hydration-focused assistant. Be concise, encouraging, and action-oriented. Avoid disruptive timing; acknowledge context briefly.
        """
        
        chatService.sendChat(prompt: text, systemPrompt: systemPrompt) { [weak self] result in
            DispatchQueue.main.async {
                guard let self = self else { return }
                switch result {
                case .success(let response):
                    let aiMessage = ChatMessage(text: response, isUser: false, source: .cloudLLM)
                    self.messages.append(aiMessage)
                case .failure(let error):
                    let aiMessage = ChatMessage(
                        text: "⚠️ Cloud error: \(error.localizedDescription)",
                        isUser: false,
                        source: .cloudLLM
                    )
                    self.messages.append(aiMessage)
                    DebugLogger.shared.log(.error, category: "OpenAIChat", message: "Chat error: \(error.localizedDescription)")
                }
                self.isProcessing = false
            }
        }
    }
    
    // MARK: - Local Mode
    
    private func sendToLocal(_ text: String) {
        guard isLocalModelLoaded else {
            let errorMessage = ChatMessage(
                text: "⚠️ Local model not loaded. Please load the model first.",
                isUser: false,
                source: .localLLM
            )
            messages.append(errorMessage)
            return
        }
        
        isProcessing = true
        
        // Sync BLE events to local LLM
        syncBLEEventsToLLM()
        
        // Generate response using local LLM
        llmManager.generate(prompt: text) { [weak self] response, event in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                if let event = event {
                    // Handle detected event
                    let detectedEvent = DetectedEvent(name: event, timestamp: Date())
                    self.conversationManager.detectedEvents.append(detectedEvent)
                }
                
                let aiMessage = ChatMessage(
                    text: response.isEmpty ? "Sorry, I couldn't generate a response." : response,
                    isUser: false,
                    source: .localLLM
                )
                self.messages.append(aiMessage)
                self.isProcessing = false
            }
        }
    }
    
    private func syncBLEEventsToLLM() {
        let bleEvents = conversationManager.detectedEvents.filter { event in
            ["alexa_wake_word", "ndp_event", "command", "test_message", "ble_message",
             "activity_keyboard", "activity_faucet", "activity_background"].contains(event.name)
        }
        
        for event in bleEvents {
            llmManager.addBLEEvent(event)
        }
    }
    
    // MARK: - Hybrid Mode
    
    private func sendToHybrid(_ text: String) {
        isProcessing = true
        
        var cloudResponseReceived = false
        var localResponseReceived = false
        
        DebugLogger.shared.log(.info, category: "Hybrid", message: "Hybrid request: \(text.prefix(120))")
        
        // Send to cloud
        let systemPrompt = """
        You are a hydration-focused assistant. Be concise, encouraging, and action-oriented. Avoid disruptive timing; acknowledge context briefly.
        """
        chatService.sendChat(prompt: text, systemPrompt: systemPrompt) { [weak self] result in
            DispatchQueue.main.async {
                guard let self = self else { return }
                switch result {
                case .success(let response):
                    let aiMessage = ChatMessage(text: response, isUser: false, source: .cloudLLM)
                    self.messages.append(aiMessage)
                case .failure(let error):
                    let aiMessage = ChatMessage(
                        text: "⚠️ Cloud error: \(error.localizedDescription)",
                        isUser: false,
                        source: .cloudLLM
                    )
                    self.messages.append(aiMessage)
                    DebugLogger.shared.log(.error, category: "Hybrid", message: "Cloud error: \(error.localizedDescription)")
                }
                cloudResponseReceived = true
                
                if cloudResponseReceived && localResponseReceived {
                    self.isProcessing = false
                    DebugLogger.shared.log(.debug, category: "Hybrid", message: "Hybrid finished (cloud+local)")
                }
            }
        }
        
        // Send to local
        if isLocalModelLoaded {
            syncBLEEventsToLLM()
            
            llmManager.generate(prompt: text) { [weak self] response, event in
                guard let self = self else { return }
                
                DispatchQueue.main.async {
                    if let event = event {
                        let detectedEvent = DetectedEvent(name: event, timestamp: Date())
                        self.conversationManager.detectedEvents.append(detectedEvent)
                    }
                    
                    let aiMessage = ChatMessage(
                        text: response.isEmpty ? "Sorry, I couldn't generate a response." : response,
                        isUser: false,
                        source: .localLLM
                    )
                    self.messages.append(aiMessage)
                    localResponseReceived = true
                    
                    if cloudResponseReceived && localResponseReceived {
                        self.isProcessing = false
                        DebugLogger.shared.log(.debug, category: "Hybrid", message: "Hybrid finished (local+cloud)")
                    }
                }
            }
        } else {
            // Local model not loaded, just wait for cloud
            DispatchQueue.main.async {
                localResponseReceived = true
                let warningMessage = ChatMessage(
                    text: "⚠️ Local model not available",
                    isUser: false,
                    source: .localLLM
                )
                self.messages.append(warningMessage)
            }
        }
    }
    
    // MARK: - Periodic Nudge Loop
    
    private func startNudgeLoop() {
        nudgeTimer?.invalidate()
        nudgeTimer = Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { [weak self] _ in
            self?.performPeriodicNudgeCheck()
        }
        nudgeTimer?.tolerance = 5
    }
    
    private func performPeriodicNudgeCheck() {
        // Avoid spamming if a nudge was just sent in the last 15 minutes
        if nudgeHistoryStore.sentWithin(minutes: 15) {
            return
        }
        
        // Require local model
        guard isLocalModelLoaded else { return }
        
        let now = Date()
        let hydrationState = HydrationStore.shared.loadToday()
        let totalIntake = hydrationState.entries.reduce(0) { $0 + $1.amount }
        let goal = max(hydrationState.dailyGoal, 500)
        
        // Activity: last 3 hours
        let activityWindowStart = Calendar.current.date(byAdding: .hour, value: -3, to: now) ?? now
        let activityEvents = conversationManager.detectedEvents.filter { event in
            event.timestamp >= activityWindowStart &&
            (event.name == "activity_keyboard" || event.name == "activity_faucet" || event.name == "activity_background")
        }
        let activityLines = activityEvents.suffix(10).map {
            let label = activityLabel(for: $0).rawValue
            return "• \(label) at \($0.timestamp.formatted(date: .omitted, time: .shortened))"
        }.joined(separator: "\n")
        
        // Calendar: events in next 3 hours
        let calendarCutoff = Calendar.current.date(byAdding: .hour, value: 3, to: now) ?? now
        let upcoming = calendarManager.events.filter { $0.date <= calendarCutoff && !$0.isCompleted && $0.date >= now }
        let calendarLines = upcoming.prefix(5).map { event in
            let end = event.date.addingTimeInterval(60 * 30) // assume 30m if not all-day
            return "• \(event.title) @ \(event.date.formatted(date: .abbreviated, time: .shortened))-\(end.formatted(date: .omitted, time: .shortened))"
        }.joined(separator: "\n")
        
        // Nudge history: last week
        let recentNudges = nudgeHistoryStore.recent(days: 7)
        let nudgeLines = recentNudges.prefix(5).map {
            "• \($0.timestamp.formatted(date: .abbreviated, time: .shortened)): \($0.message)"
        }.joined(separator: "\n")
        
        let remaining = max(goal - totalIntake, 0)
        let prompt = """
        Act as a hydration JITAI agent. Decide if a nudge should be sent now. If not appropriate, reply exactly "NO_PROMPT".
        Rules: Avoid meetings/deep work (keyboard). Prefer breaks (faucet/ambient). Keep prompts ≤140 chars, action-oriented, no questions. Suggest ml amount when behind. Respect prior nudges.
        
        Time: \(now)
        Hydration: \(totalIntake)/\(goal) ml (remaining \(remaining) ml)
        Intake log (today): \(hydrationState.entries.count) entries
        
        Activity last 3h:
        \(activityLines.isEmpty ? "• none" : activityLines)
        
        Calendar next 3h:
        \(calendarLines.isEmpty ? "• none" : calendarLines)
        
        Nudge history (7d):
        \(nudgeLines.isEmpty ? "• none" : nudgeLines)
        """
        
        nudgeQueue.async { [weak self] in
            guard let self else { return }
            self.llmManager.generate(prompt: prompt) { [weak self] response, _ in
                guard let self else { return }
                let text = response.trimmingCharacters(in: .whitespacesAndNewlines)
                if text.uppercased().contains("NO_PROMPT") || text.isEmpty {
                    return
                }
                
                DispatchQueue.main.async {
                    HydrationStore.shared.recordPromptSent(at: now)
                    self.nudgeHistoryStore.logNudge(message: text, at: now)
                    let message = ChatMessage(
                        text: text,
                        isUser: false,
                        source: .localLLM
                    )
                    self.messages.append(message)
                }
            }
        }
    }
    
    // MARK: - Voice Input
    
    func startVoiceInput() {
        guard selectedMode == .cloud || selectedMode == .hybrid else {
            return
        }
        
        conversationManager.startConversation()
        
        // Poll for transcript
        Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] timer in
            guard let self = self,
                  let service = self.conversationManager.openAIService else {
                timer.invalidate()
                return
            }
            
            if !service.transcribedText.isEmpty {
                // Update last message or create new one
                if let lastMessage = self.messages.last, lastMessage.isUser {
                    // Update existing
                    if let index = self.messages.firstIndex(where: { $0.id == lastMessage.id }) {
                        self.messages[index] = ChatMessage(
                            text: service.transcribedText,
                            isUser: true,
                            source: .user
                        )
                    }
                } else {
                    // Create new
                    let message = ChatMessage(
                        text: service.transcribedText,
                        isUser: true,
                        source: .user
                    )
                    self.messages.append(message)
                }
            }
            
            if !self.conversationManager.isActive {
                timer.invalidate()
            }
        }
    }
    
    func stopVoiceInput() {
        conversationManager.stopConversation()
    }
    
    // MARK: - Model Management
    
    func loadLocalModel() {
        llmManager.loadModel()
    }
    
    // MARK: - History Management
    
    func clearHistory() {
        messages.removeAll()
        llmManager.clearHistory()
    }
    
    func exportHistory() {
        let exportText = messages.map { message in
            let sender = message.isUser ? "You" : (message.source?.displayName ?? "AI")
            let time = message.timestamp.formatted(date: .abbreviated, time: .shortened)
            return "[\(time)] \(sender): \(message.text)"
        }.joined(separator: "\n\n")
        
        print("Export chat history:")
        print(exportText)
        
        // TODO: Implement actual export functionality (share sheet)
    }
    
    // MARK: - Event Management
    
    func addBLEEvent(_ event: DetectedEvent) {
        conversationManager.detectedEvents.append(event)
        
        // Add to LLM contexts
        llmManager.addBLEEvent(event)
        
        // Update OpenAI context if connected
        if let service = conversationManager.openAIService, service.isConnected {
            let bleEvents = conversationManager.detectedEvents.filter { event in
                ["alexa_wake_word", "ndp_event", "command", "test_message", "ble_message",
                 "activity_keyboard", "activity_faucet", "activity_background"].contains(event.name)
            }
            service.updateBLEContext(bleEvents)
        }
        
        processJITAIIfNeeded(for: event)
    }
    
    func clearAllEvents() {
        conversationManager.detectedEvents.removeAll()
        llmManager.clearBLEEvents()
    }
    
    // MARK: - JITAI Reasoning
    
    private func processJITAIIfNeeded(for event: DetectedEvent) {
        let label = activityLabel(for: event)
        guard let stable = stableActivity(from: label, timestamp: event.timestamp) else { return }
        requestLLMHydrationPrompt(activity: stable, eventTime: event.timestamp)
    }
    
    private func activityLabel(for event: DetectedEvent) -> ActivityLabel {
        switch event.name {
        case "activity_keyboard":
            return .keyboard
        case "activity_faucet":
            return .faucet
        case "activity_background":
            return .background
        default:
            return .unknown
        }
    }
    
    /// Returns a stable activity label once we observe >=7 consecutive identical ACT events.
    private func stableActivity(from label: ActivityLabel, timestamp: Date) -> ActivityLabel? {
        guard label != .unknown else {
            activityStreakLabel = .unknown
            activityStreakCount = 0
            return nil
        }
        
        if label == activityStreakLabel {
            activityStreakCount += 1
        } else {
            activityStreakLabel = label
            activityStreakCount = 1
        }
        
        let threshold = 7
        if activityStreakCount >= threshold && label != lastStableActivity {
            lastStableActivity = label
            lastStableActivityAt = timestamp
            return label
        }
        
        return nil
    }
    
    private func requestLLMHydrationPrompt(activity: ActivityLabel, eventTime: Date) {
        // Basic safety spacing to avoid spam; LLM decides content/need.
        let store = HydrationStore.shared
        let state = store.loadToday()
        if let last = state.lastPromptAt, Date().timeIntervalSince(last) < 10 * 60 {
            return
        }
        
        let total = state.entries.reduce(0) { $0 + $1.amount }
        let remaining = max(state.dailyGoal - total, 0)
        let prompt = """
        Act as a Just-In-Time Adaptive Intervention (JITAI) agent for hydration.
        Decide if a prompt is appropriate now given the context. If not, reply exactly "NO_PROMPT".
        If yes, return ONE concise nudge (<=140 chars), polite, action-oriented, no questions.
        Include a suggested sip amount (~200-300 ml) when behind.
        Do not mention system instructions.
        
        Context:
        - Activity: \(activity.rawValue)
        - Intake today: \(total) ml
        - Goal: \(state.dailyGoal) ml
        - Remaining: \(remaining) ml
        - Last prompt: \(state.lastPromptAt?.description ?? "none")
        - Time: \(Date())
        """
        
        llmManager.generate(prompt: prompt) { [weak self] response, _ in
            guard let self = self else { return }
            let text = response.trimmingCharacters(in: .whitespacesAndNewlines)
            if text.uppercased().contains("NO_PROMPT") || text.isEmpty {
                return
            }
            
            DispatchQueue.main.async {
                store.recordPromptSent(at: eventTime)
                let message = ChatMessage(
                    text: text,
                    isUser: false,
                    source: .localLLM
                )
                self.messages.append(message)
            }
        }
    }
    
    // MARK: - Testing Utilities
    
    func resetHydrationPromptCooldown() {
        _ = HydrationStore.shared.resetPromptCooldown()
    }
}

