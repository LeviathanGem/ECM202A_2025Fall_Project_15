//
//  CalendarEvent.swift
//  OdysseyTest
//
//  Calendar event data model for agenda management
//

import Foundation

struct CalendarEvent: Identifiable, Codable, Equatable {
    var id: UUID
    var title: String
    var notes: String
    var date: Date
    var isAllDay: Bool
    var category: EventCategory
    var isCompleted: Bool
    
    init(
        id: UUID = UUID(),
        title: String,
        notes: String = "",
        date: Date = Date(),
        isAllDay: Bool = false,
        category: EventCategory = .wellness,
        isCompleted: Bool = false
    ) {
        self.id = id
        self.title = title
        self.notes = notes
        self.date = date
        self.isAllDay = isAllDay
        self.category = category
        self.isCompleted = isCompleted
    }
    
    var formattedDate: String {
        let formatter = DateFormatter()
        if isAllDay {
            formatter.dateStyle = .medium
            formatter.timeStyle = .none
        } else {
            formatter.dateStyle = .medium
            formatter.timeStyle = .short
        }
        return formatter.string(from: date)
    }
    
    var isUpcoming: Bool {
        date > Date()
    }
    
    var isPast: Bool {
        date < Date()
    }
}

enum EventCategory: String, Codable, CaseIterable {
    case wellness = "Wellness"
    case maintenance = "Maintenance"
    case training = "Training"
    case race = "Race"
    case social = "Social"
    case weather = "Weather"
    case other = "Other"
    
    var icon: String {
        switch self {
        case .wellness: return "drop.fill"
        case .maintenance: return "wrench.fill"
        case .training: return "graduationcap.fill"
        case .race: return "flag.checkered"
        case .social: return "person.3.fill"
        case .weather: return "cloud.sun.fill"
        case .other: return "calendar"
        }
    }
    
    var color: String {
        switch self {
        case .wellness: return "blue"
        case .maintenance: return "orange"
        case .training: return "green"
        case .race: return "red"
        case .social: return "purple"
        case .weather: return "cyan"
        case .other: return "gray"
        }
    }
}

