//
//  NudgeHistoryStore.swift
//  OdysseyTest
//
//  Tracks hydration nudges over a rolling 7-day window.
//

import Foundation

struct NudgeRecord: Identifiable, Codable {
    let id: UUID
    let message: String
    let timestamp: Date
    
    init(id: UUID = UUID(), message: String, timestamp: Date = Date()) {
        self.id = id
        self.message = message
        self.timestamp = timestamp
    }
}

final class NudgeHistoryStore {
    static let shared = NudgeHistoryStore()
    
    private let storageKey = "odyssey_nudge_history"
    private let decoder = JSONDecoder()
    private let encoder = JSONEncoder()
    
    private init() {}
    
    func recent(days: Int = 7) -> [NudgeRecord] {
        let cutoff = Calendar.current.date(byAdding: .day, value: -days, to: Date()) ?? Date()
        let records = loadAll().filter { $0.timestamp >= cutoff }
        return records.sorted { $0.timestamp > $1.timestamp }
    }
    
    func logNudge(message: String, at date: Date = Date()) {
        var records = loadAll()
        records.append(NudgeRecord(message: message, timestamp: date))
        save(records)
        DebugLogger.shared.log(.info, category: "Nudge", message: "Logged nudge: \(message)")
    }
    
    func sentWithin(minutes: Double) -> Bool {
        guard let last = recent(days: 7).first else { return false }
        let elapsed = Date().timeIntervalSince(last.timestamp) / 60
        return elapsed < minutes
    }
    
    // MARK: - Persistence
    
    private func loadAll() -> [NudgeRecord] {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let records = try? decoder.decode([NudgeRecord].self, from: data) else {
            return []
        }
        return records
    }
    
    private func save(_ records: [NudgeRecord]) {
        let trimmed = trimToSevenDays(records)
        if let data = try? encoder.encode(trimmed) {
            UserDefaults.standard.set(data, forKey: storageKey)
        }
    }
    
    private func trimToSevenDays(_ records: [NudgeRecord]) -> [NudgeRecord] {
        let cutoff = Calendar.current.date(byAdding: .day, value: -7, to: Date()) ?? Date()
        return records.filter { $0.timestamp >= cutoff }
    }
}

