//
//  LocalChatbot.swift
//  OdysseyTest
//
//  Local pattern-matching chatbot for offline use
//

import Foundation

class LocalChatbot {
    
    // MARK: - Intent Detection
    
    enum Intent {
        case logWater
        case setGoal
        case hydrationStatus
        case hydrationPrompt
        case greeting
        case help
        case unknown
        
        var eventName: String? {
            switch self {
            case .logWater: return "log_water_intake"
            case .setGoal: return "set_hydration_goal"
            case .hydrationStatus: return "hydration_status"
            case .hydrationPrompt: return "hydration_prompt"
            default: return nil
            }
        }
    }
    
    // MARK: - Pattern Matching
    
    private let logWaterPatterns = [
        "log", "record", "save", "note", "add",
        "water", "drink", "hydration", "cup", "ml", "ounce", "glass"
    ]
    
    private let setGoalPatterns = [
        "goal", "target", "daily", "quota", "aim", "set"
    ]
    
    private let statusPatterns = [
        "status", "progress", "how am i doing", "remaining", "left", "today"
    ]
    
    private let promptPatterns = [
        "remind", "nudge", "prompt", "hydrate", "thirst", "take a sip"
    ]
    
    private let greetingPatterns = [
        "hello", "hi", "hey", "greetings", "good morning",
        "good afternoon", "good evening"
    ]
    
    private let helpPatterns = [
        "help", "what can", "how do", "commands", "options"
    ]
    
    // MARK: - Intent Detection
    
    func detectIntent(from text: String) -> Intent {
        let lowercased = text.lowercased()
        
        // Check for greetings
        if containsAny(lowercased, patterns: greetingPatterns) {
            return .greeting
        }
        
        // Check for help
        if containsAny(lowercased, patterns: helpPatterns) {
            return .help
        }
        
        // Check for logging water
        if containsMultiple(lowercased, patterns: logWaterPatterns, minMatches: 2) {
            return .logWater
        }
        
        // Check for goal change
        if containsMultiple(lowercased, patterns: setGoalPatterns, minMatches: 2) {
            return .setGoal
        }
        
        // Check hydration status
        if containsAny(lowercased, patterns: statusPatterns) {
            return .hydrationStatus
        }
        
        // Check for reminder request
        if containsAny(lowercased, patterns: promptPatterns) {
            return .hydrationPrompt
        }
        
        return .unknown
    }
    
    // MARK: - Response Generation
    
    func generateResponse(for intent: Intent) -> String {
        switch intent {
        case .logWater:
            return "💧 Logged your intake at \(formattedTime()). Keep the steady sips going."
            
        case .setGoal:
            return "🎯 Got it—I'll update your daily hydration goal."
            
        case .hydrationStatus:
            return "📊 Here's your hydration status for today. I'll summarize what's left."
            
        case .hydrationPrompt:
            return "🚰 Quick nudge: take ~200 ml now if you can."
            
        case .greeting:
            return "👋 Hello! I'm your local hydration coach. How can I help you today?"
            
        case .help:
            return """
            💧 I can help you with:
            • "Log 250 ml" - Record water you just drank
            • "Set my goal to 2200" - Update your daily target
            • "How am I doing?" - Get a quick status
            • "Remind me to drink" - Ask for a gentle nudge
            
            Just speak naturally, and I'll understand!
            """
            
        case .unknown:
            return "🤔 I'm not sure I understood that. Try saying 'help' to see what I can do!"
        }
    }
    
    // MARK: - Helper Methods
    
    private func containsAny(_ text: String, patterns: [String]) -> Bool {
        return patterns.contains { text.contains($0) }
    }
    
    private func containsMultiple(_ text: String, patterns: [String], minMatches: Int) -> Bool {
        let matches = patterns.filter { text.contains($0) }.count
        return matches >= minMatches
    }
    
    private func formattedTime() -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: Date())
    }
    
    // MARK: - Process User Input
    
    func processInput(_ text: String) -> (response: String, intent: Intent) {
        let intent = detectIntent(from: text)
        let response = generateResponse(for: intent)
        return (response, intent)
    }
}

