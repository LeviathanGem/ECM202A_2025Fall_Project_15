# 🦙 Local LLM Integration Setup Guide

## ⚠️ Important: Manual Setup Required

I've created all the Swift code, but you need to **manually add llama.cpp** to your Xcode project.

---

## 📦 Step 1: Add llama.cpp Dependency

### Option A: Using Swift Package Manager (Recommended)

1. Open your project in **Xcode**
2. Go to **File → Add Package Dependencies...**
3. Enter this URL:
   ```
   https://github.com/ggerganov/llama.cpp
   ```
4. Select **"Up to Next Major Version"**
5. Click **Add Package**
6. Select **"llama"** library
7. Click **Add Package**

### Option B: Using a Swift Wrapper (Easier)

Use one of these pre-made Swift wrappers:

**llama-cpp-swift** (Recommended):
```
https://github.com/ShenghaiWang/SwiftLlama
```

**LLM.swift**:
```
https://github.com/eastriverlee/LLM.swift
```

Add via SPM as above.

---

## 📥 Step 2: Download Model File

You need a quantized model file (`.gguf` format).

### Recommended: TinyLlama 1.1B Q4_K_M

**Download from:**
- Hugging Face: https://huggingface.co/TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF

**Direct link:**
```
https://huggingface.co/TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF/resolve/main/tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf
```

**File size:** ~669 MB

### Where to Put It:

**Option 1: Bundle with App** (Increases app size by 669MB)
1. Add to Xcode project
2. Add to **"Copy Bundle Resources"**
3. Access via `Bundle.main.path()`

**Option 2: Download on First Use** (Recommended)
1. Download to Documents directory
2. Use ModelDownloader.swift (I've created this)
3. Show progress UI to user

---

## 🔧 Step 3: Update Build Settings

If using llama.cpp directly (not a wrapper):

1. Go to **Build Settings**
2. Find **"C++ Language Dialect"**
3. Set to **"GNU++17"** or **"C++17"**
4. Find **"Enable Bitcode"**
5. Set to **"No"**

---

## 📱 Step 4: Increase Memory Limits

LLMs need more memory:

1. Go to project **Info.plist**
2. Add if not exists:
   ```xml
   <key>UIApplicationExitsOnSuspend</key>
   <false/>
   ```

---

## ✅ Step 5: Test the Integration

Once you've added the dependency:

1. Build the project (⌘B)
2. If it compiles → You're good!
3. If not → Check the error messages

Common issues:
- **"No such module 'llama'"** → Package not added correctly
- **C++ errors** → Check C++ dialect setting
- **Linker errors** → Check library is linked

---

## 🎯 What I've Already Created:

All these files are ready in your project:

1. ✅ **LLMManager.swift** - Manages the LLM
2. ✅ **ModelDownloader.swift** - Downloads model
3. ✅ **Updated ChatView.swift** - Uses LLM
4. ✅ **LLMConfig.swift** - Configuration

Just add llama.cpp and you're done!

---

## 🚀 Quick Start (After Adding Dependency):

1. **Build** the project
2. **Run** on iPhone
3. **Go to Chat tab**
4. **First time**: Model downloads (~669MB, takes a few minutes)
5. **After download**: Tap 🎤 or type
6. **Get intelligent LLM responses!**

---

## 💡 Alternative: Test Without Integration First

Want to see if it works on your iPhone before integrating?

1. Download **"LLM Farm"** app from App Store
2. Download TinyLlama model
3. Test it on your device
4. If it works well → Integrate into your app!

---

## 🆘 Need Help?

If you get stuck:
1. Check llama.cpp GitHub issues
2. Check the Swift wrapper's documentation
3. Let me know the error and I'll help!

---

## 📊 Expected Performance:

Once working, you should see:
- **Load time**: 2-5 seconds
- **Response time**: 2-5 seconds
- **Quality**: Natural conversation
- **Memory**: ~1GB RAM

---

Ready? Add the llama.cpp package and let's test it! 🚀

