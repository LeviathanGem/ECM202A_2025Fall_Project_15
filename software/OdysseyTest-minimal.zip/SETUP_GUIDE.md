# Odyssey Companion - Setup Guide

## 🎉 OpenAI Realtime API Integration Complete!

Your app now has full voice interaction with event detection capabilities.

## 📋 What Was Built

### Core Files Created:

1. **AudioRecorder.swift** - Captures microphone input and streams it
2. **OpenAIRealtimeService.swift** - WebSocket connection to OpenAI Realtime API
3. **ConversationManager.swift** - Coordinates everything
4. **Config.swift** - API key management
5. **Info.plist** - Microphone permissions
6. **Updated ContentView.swift** - Full UI with voice controls

---

## 🚀 Setup Instructions

### Step 1: Add Your OpenAI API Key

1. Open `Config.swift`
2. Replace `YOUR_API_KEY_HERE` with your actual OpenAI API key:

```swift
static let openAIAPIKey = "sk-proj-xxxxxxxxxxxxx"
```

**Get your API key from:** https://platform.openai.com/api-keys

⚠️ **Security Note:** Never commit API keys to git! Add `Config.swift` to `.gitignore` in production.

### Step 2: Add Microphone Permissions in Xcode

You need to add privacy permissions for microphone access:

1. Open your project in **Xcode**
2. Select the **OdysseyTest** target (blue icon at top of file list)
3. Click on the **Info** tab
4. Click the **+** button to add new entries
5. Add these two entries:

   **First Entry:**
   - Key: **Privacy - Microphone Usage Description**
   - Value: `Odyssey Companion needs microphone access to listen to your voice commands and conversations.`

   **Second Entry:**
   - Key: **Privacy - Speech Recognition Usage Description**  
   - Value: `Odyssey Companion uses speech recognition to understand your hydration-related requests.`

Alternatively, you can add to `OdysseyTestApp.swift` or any swift file in your target the following:
```swift
// Required for iOS 14+ Info.plist configuration
```

Or in the project's **Custom iOS Target Properties**, search for "Privacy" and add the microphone usage descriptions.

### Step 3: Build & Run

1. Connect your iPhone/iPad or use simulator (Note: Simulator microphone has limitations)
2. Build and run the app (⌘R)
3. Grant microphone permission when prompted
4. Tap the droplet circle to start recording

---

## 🎯 How It Works

### Voice Interaction

1. **Tap the droplet** → Starts recording
2. **Speak naturally** → Your audio streams to OpenAI in real-time
3. **Events are detected** → Specific actions trigger function calls
4. **Tap again** → Stops recording

### Detected Events

The AI recognizes hydration-related intents:

| Event | Trigger Phrases | Icon |
|-------|----------------|------|
| **log_water_intake** | "Log 250 ml", "I drank a glass" | 💧 |
| **hydration_status** | "How am I doing?", "Hydration status" | 📊 |
| **set_hydration_goal** | "Set my goal to 2200" | 🎯 |
| **hydration_prompt** | "Remind me to drink", "Nudge me later" | 🚰 |

### UI Features

- **Blue → Green Circle**: Shows recording state
- **Breathing Animation**: Visual feedback during recording
- **Audio Level Ring**: Pulses with your voice
- **Transcript Box**: Shows what you're saying
- **Events List**: View all detected events

---

## 🔧 Customization

### Add More Events

Edit `OpenAIRealtimeService.swift` in the `sendSessionUpdate()` function:

```swift
[
    "type": "function",
    "name": "your_event_name",
    "description": "When to trigger this event",
    "parameters": [
        "type": "object",
        "properties": [:] as [String: Any],
        "required": []
    ]
]
```

Then add the emoji/display name in `ConversationManager.swift`:

```swift
var displayName: String {
    switch name {
    case "your_event_name":
        return "🆕 Your Event"
    // ... other cases
    }
}
```

### Adjust Audio Settings

In `AudioRecorder.swift`, modify:
- Sample rate (currently 24kHz)
- Buffer size (currently 4096)
- Audio format

### Change Animation Speed

In `ContentView.swift`, adjust:
```swift
.animation(.easeInOut(duration: 2.0) // Change duration here
```

---

## 📱 Testing Tips

### Test Phrases to Try:

- "Log 250 milliliters"
- "How am I doing on water today?"
- "Set my goal to 2200 ml"
- "Remind me to drink after this meeting"

### Troubleshooting:

**No microphone permission:**
- Go to Settings → OdysseyTest → Enable Microphone

**API errors:**
- Check your API key is valid
- Ensure you have credits in your OpenAI account
- Check console for error messages

**No audio level indicator:**
- Speak louder
- Check microphone is working in other apps

**Simulator issues:**
- Audio recording works better on real devices
- Some features may not work in simulator

---

## 💰 OpenAI Costs

The Realtime API costs are usage-based:
- **Input audio**: ~$0.06 per minute
- **Output audio**: ~$0.24 per minute

Monitor your usage at: https://platform.openai.com/usage

---

## 🎨 Next Steps

### Suggested Enhancements:

1. **Add actual functionality** to detected events (e.g., GPS logging, weather API integration)
2. **Store conversation history** in local database
3. **Add text-to-speech** for AI responses
4. **Create settings screen** for API key input
5. **Add wake word detection** for hands-free activation
6. **Implement audio playback** of AI responses
7. **Add haptic feedback** for events
8. **Create trip logging** feature

---

## 📚 Resources

- [OpenAI Realtime API Docs](https://platform.openai.com/docs/guides/realtime)
- [SwiftUI Documentation](https://developer.apple.com/documentation/swiftui/)
- [AVFoundation Audio](https://developer.apple.com/documentation/avfoundation/)

---

## 🐛 Known Limitations

1. **Simulator audio**: Works better on real devices
2. **Background recording**: Not yet implemented
3. **Network required**: No offline mode
4. **API latency**: Depends on internet connection

---

Enjoy building your hydration companion app! 💧

