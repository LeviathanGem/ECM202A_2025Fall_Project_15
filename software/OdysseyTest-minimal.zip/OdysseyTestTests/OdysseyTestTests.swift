//
//  OdysseyTestTests.swift
//  OdysseyTestTests
//
//  Created by Assia LI on 2025/10/24.
//

import Testing
@testable import OdysseyTest

struct OdysseyTestTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
