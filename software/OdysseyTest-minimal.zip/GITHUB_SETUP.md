# 🐙 GitHub Repository Setup Guide

Quick guide to push your OdysseyTest project to GitHub safely.

## ⚠️ Before You Push - Critical Steps

### 1. **Verify `.gitignore` is Working**

Check that sensitive files are ignored:

```bash
cd /Users/assiali/Desktop/Projects/OdysseyTest

# This should show NOTHING (if it does, DON'T PUSH YET!)
git check-ignore OdysseyTest/Config.swift

# Expected output: "OdysseyTest/Config.swift" (means it's ignored ✅)
```

### 2. **Check for API Keys**

Make sure your API key won't be committed:

```bash
# Search for any API keys in tracked files (should return nothing)
git grep -i "sk-proj-" || echo "✅ No API keys found in tracked files"
git grep -i "openai.*key" || echo "✅ No API key references found"
```

### 3. **Verify Large Files Are Ignored**

```bash
# Check if model files are ignored (should show the .gitignore rule)
git check-ignore *.gguf Models/

# List all files that will be committed (should NOT include large files)
git ls-files | grep -E "\.(gguf|bin|safetensors)$" || echo "✅ No large model files tracked"
```

## 🚀 Initial GitHub Setup

### Option A: Create New Repository on GitHub First (Recommended)

1. **Go to GitHub** and create a new repository:
   - Name: `OdysseyTest` (or your preferred name)
   - Description: "Context-aware hydration JITAI for iOS"
   - Visibility: Choose **Private** (recommended) or Public
   - ⚠️ **Do NOT** initialize with README (we already have one)

2. **Initialize local git repository:**

```bash
cd /Users/assiali/Desktop/Projects/OdysseyTest

# Initialize git (if not already done)
git init

# Add all files (respecting .gitignore)
git add .

# Check what will be committed
git status

# IMPORTANT: Verify Config.swift is NOT in the list!
# If it is, STOP and check your .gitignore
```

3. **Verify before committing:**

```bash
# Double-check no secrets are being committed
git diff --cached | grep -i "sk-proj" && echo "⚠️ WARNING: API KEY FOUND!" || echo "✅ Safe to commit"
```

4. **Make initial commit:**

```bash
git commit -m "Initial commit: Odyssey Companion - hydration JITAI assistant

Features:
- Cloud voice AI via OpenAI Realtime API
- Local on-device chat with TinyLlama
- Event detection and logging
- SwiftUI interface with tab navigation
- Millisecond-precision timestamping system"
```

5. **Connect to GitHub and push:**

```bash
# Replace YOUR_GITHUB_USERNAME with your actual username
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/OdysseyTest.git

# Set main as default branch
git branch -M main

# Push to GitHub
git push -u origin main
```

### Option B: Use GitHub CLI (gh)

If you have GitHub CLI installed:

```bash
cd /Users/assiali/Desktop/Projects/OdysseyTest

git init
git add .
git commit -m "Initial commit: Odyssey Companion iOS app"

# Create repo and push in one command
gh repo create OdysseyTest --private --source=. --push

# Or for public repo:
# gh repo create OdysseyTest --public --source=. --push
```

## 📝 Post-Setup Checklist

After pushing to GitHub, verify:

### ✅ What SHOULD be in the repo:

- [ ] Source code files (`.swift`)
- [ ] Xcode project file (`.xcodeproj/project.pbxproj`)
- [ ] Documentation (`.md` files)
- [ ] `.gitignore` file
- [ ] `Config.swift.template` (template file)
- [ ] Asset catalogs
- [ ] Scheme files (shared)

### ❌ What should NOT be in the repo:

- [ ] `Config.swift` (contains API key) ⚠️ CRITICAL
- [ ] `*.gguf` files (669MB model)
- [ ] `xcuserdata/` folders
- [ ] `.DS_Store` files
- [ ] Build artifacts (`DerivedData/`, `build/`)
- [ ] `.xcuserstate` files

### Verify on GitHub:

1. Go to your repository on GitHub.com
2. Check the file list - you should NOT see:
   - `Config.swift` (only `Config.swift.template` should be there)
   - Any `.gguf` model files
   - Any `xcuserdata` folders
3. Check the README renders correctly
4. Verify the repository size is < 50 MB

## 🔄 Daily Workflow

After initial setup, use this workflow:

```bash
# 1. Check what changed
git status

# 2. Review changes (make sure no secrets!)
git diff

# 3. Add files
git add .

# 4. Commit with descriptive message
git commit -m "Add feature: [describe your change]"

# 5. Push to GitHub
git push
```

## 🚨 Emergency: If You Accidentally Committed Secrets

If you accidentally committed your API key:

### ⚠️ DO NOT just delete the file and commit again!
The API key will still be in git history!

Instead:

1. **Immediately rotate your API key** on OpenAI platform:
   - Go to https://platform.openai.com/api-keys
   - Delete the exposed key
   - Create a new one

2. **Remove the key from git history:**

```bash
# Use BFG Repo Cleaner (safest method)
# Download from: https://rtyley.github.io/bfg-repo-cleaner/

# Remove Config.swift from all commits
bfg --delete-files Config.swift

# Clean up
git reflog expire --expire=now --all
git gc --prune=now --aggressive

# Force push (⚠️ only if you're the only collaborator)
git push --force
```

3. **Or use git-filter-repo (alternative):**

```bash
# Install: pip install git-filter-repo

# Remove Config.swift from history
git filter-repo --path OdysseyTest/Config.swift --invert-paths

# Force push
git push --force
```

## 🌐 Making Repository Public (Optional)

If you want to share your project publicly:

1. **Double-check security:**
   ```bash
   # Search entire history for API keys
   git log -p | grep -i "sk-proj" && echo "⚠️ KEYS IN HISTORY!" || echo "✅ Safe"
   ```

2. **Update README:**
   - Add your contact information
   - Choose a license (MIT recommended)
   - Update repository URLs

3. **Change visibility on GitHub:**
   - Go to Settings → Danger Zone → Change visibility → Make public

## 📦 Optional: Add GitHub Actions (CI/CD)

Create `.github/workflows/ios.yml` for automated testing:

```yaml
name: iOS Build

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: macos-latest
    steps:
    - uses: actions/checkout@v3
    - name: Build
      run: xcodebuild -project OdysseyTest.xcodeproj -scheme OdysseyTest -sdk iphonesimulator build
```

## 📱 Distribution Options

Once on GitHub:

### TestFlight (Official Apple Beta Testing)
1. Archive in Xcode
2. Upload to App Store Connect
3. Submit for beta testing

### Self-Distribution (Enterprise)
1. Export IPA from Xcode
2. Distribute via enterprise certificate

### Open Source Community
1. Make repo public
2. Add contributing guidelines
3. Tag releases with semantic versioning

## 🆘 Common Issues

### Issue: "Config.swift showing in git status"

**Solution:**
```bash
# Remove from staging
git rm --cached OdysseyTest/Config.swift

# Verify .gitignore has the rule
grep "Config.swift" .gitignore

# Re-add all files
git add .
```

### Issue: "Repository is huge (>100MB)"

**Solution:**
```bash
# Check what's taking up space
git count-objects -vH

# Find large files
git rev-list --objects --all | \
  git cat-file --batch-check='%(objecttype) %(objectname) %(objectsize) %(rest)' | \
  awk '$1 == "blob" && $3 > 10485760' | \
  cut -d ' ' -f 2- | \
  sort --numeric-sort --key=2

# Likely culprit: .gguf model files - make sure they're in .gitignore
```

### Issue: "Push rejected - file too large"

**Solution:**
```bash
# Remove large files from history with BFG
bfg --strip-blobs-bigger-than 50M

# Or remove specific file types
bfg --delete-files '*.gguf'

# Clean up and force push
git reflog expire --expire=now --all
git gc --prune=now --aggressive
git push --force
```

## ✅ Final Checklist

Before sharing your repository:

- [ ] `.gitignore` is properly configured
- [ ] `Config.swift` is NOT in the repository
- [ ] API keys are NOT in git history
- [ ] Model files (*.gguf) are NOT committed
- [ ] README.md has been updated with your information
- [ ] Documentation files are up to date
- [ ] Repository size is reasonable (< 50MB)
- [ ] Build succeeds after fresh clone
- [ ] Privacy permissions are documented

---

**🎉 You're ready to push to GitHub safely!**

Questions? Check [TROUBLESHOOTING.md](TROUBLESHOOTING.md) or open an issue.

